#include "main.h"

pros::Controller master(pros::E_CONTROLLER_MASTER);

pros::Motor front_left(11, pros::E_MOTOR_GEARSET_18, 0, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor back_left(12, pros::E_MOTOR_GEARSET_18, 0, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor front_right(9, pros::E_MOTOR_GEARSET_18, 1, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor back_right(2, pros::E_MOTOR_GEARSET_18, 1, pros::E_MOTOR_ENCODER_DEGREES);

pros::Motor back_arm(13, pros::E_MOTOR_GEARSET_36, 1, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor four_bar(10, pros::E_MOTOR_GEARSET_36, 0, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor front_mogo(3, pros::E_MOTOR_GEARSET_36, 1, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor four_bar2(7, pros::E_MOTOR_GEARSET_18, 1, pros::E_MOTOR_ENCODER_DEGREES);

pros::Imu inertial(5);

pros::ADIDigitalIn four_bar_limit(1);
pros::ADIDigitalIn four_bar_limit2(3);
pros::ADIDigitalIn back_arm_limit(2);
pros::ADIDigitalIn front_mogo_limit(4);
pros::ADIEncoder encoder(5, 6, false);
pros::ADIDigitalOut pneumatics(7);

/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 *//*
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}*/

double average(int a, int b) {
  return 0.5 * (a + b);
}
double daverage(int a, int b) {
  return 0.5 * (a + b);
}
double angleConvert(double angle) {
  return angle > 180 ? angle - 360 : angle;
}
double curve(double n, double x) {
  return std::min(pow(pow(100, 2 * n) - pow(x, 2 * n), 1 / (2 * n)), 10 + 1 * x);
}
double linear_accel(double x) {
  return 40 + 4 * x > 100 ? 100 : 40 + 4 * x;
}
double linear(double x, double x1, double y1, double x2, double y2) {
  return (y2 - y1) / (x2 - x1) * (x - x1) + y1;
}
double inverse_linear(double x, double x1, double y1, double x2, double y2) {
  return (x2 - x1) / (y2 - y1) * (x - y1) + x1;
}
int map(double input) {
  double value = 0;
  double x = input * 1.3;

  if (x < 12) {
    value = inverse_linear(x, 0, 0, 15, 12);
  } else if (x < 19) {
    value = inverse_linear(x, 15, 12, 20, 19);
  } else if (x < 26) {
    value = inverse_linear(x, 20, 19, 25, 26);
  } else if (x < 32) {
    value = inverse_linear(x, 25, 26, 30, 32);
  } else if (x < 39) {
    value = inverse_linear(x, 30, 32, 35, 39);
  } else if (x < 47) {
    value = inverse_linear(x, 35, 39, 40, 47);
  } else if (x < 53) {
    value = inverse_linear(x, 40, 47, 45, 53);
  } else if (x < 66) {
    value = inverse_linear(x, 45, 53, 50, 66);
  } else if (x < 69) {
    value = inverse_linear(x, 50, 66, 55, 69);
  } else if (x < 75) {
    value = inverse_linear(x, 55, 69, 60, 75);
  } else if (x < 82) {
    value = inverse_linear(x, 60, 75, 65, 82);
  } else if (x < 88) {
    value = inverse_linear(x, 65, 82, 70, 88);
  } else if (x < 95) {
    value = inverse_linear(x, 70, 88, 75, 95);
  } else if (x < 102) {
    value = inverse_linear(x, 75, 95, 80, 102);
  } else if (x < 108) {
    value = inverse_linear(x, 80, 102, 85, 108);
  } else if (x < 114) {
    value = inverse_linear(x, 85, 108, 90, 114);
  } else if (x < 121) {
    value = inverse_linear(x, 90, 114, 95, 121);
  } else {
    value = inverse_linear(x, 95, 121, 100, 130);
  }

  return (int)value;
}
/*
int TIMEOUT1 = 0;
bool TIMED_OUT1 = false;
bool timeout1_activate = false;

void reset_timeout1() {
  TIMED_OUT1 = false;
  TIMEOUT1 = 0;
}
int timeout1() {
	while (1) {
		if (timeout1_activate) {
		  TIMED_OUT1 = false;
		  pros::delay(TIMEOUT1);
		  TIMED_OUT1 = true;
	  }
		timeout1_activate = false;
	}
	return 0;
}

pros::Task back_arm_timeout(timeout1);

int back_arm_movement() {
  bool L2 = false;
  bool L2p = false;

  bool arm_state = true;

  int movements = 0;

  double error = 0;
  double kp = 0.5;

  back_arm.set_zero_position(0);

  while (1) {
    L2 = master.get_digital(DIGITAL_L2);

    if (!L2 && L2p && !arm_state) {
      reset_timeout1();
      TIMEOUT1 = 2500;

      arm_state = true;

      while (back_arm.position(degrees) < -800) {
        back_arm.spin(fwd, 12.0, volt);

        if (TIMED_OUT1) {
          timeout_thread1.interrupt();
          reset_timeout1();
          break;
        }
      }

      back_arm.stop(brake);
    } else if (!L2 && L2p && arm_state) {
      reset_timeout1();
      TIMEOUT1 = 2500;

      arm_state = false;

      while (back_arm.position(degrees) > -1600 + movements * 15) {
        back_arm.spin(fwd, -12.0, volt);

        if (TIMED_OUT1) {
          timeout_thread1.resume();
          reset_timeout1();
          break;
        }
      }

      movements++;
      back_arm.stop(brake);
    }

    if (arm_state && !back_arm_limit.pressing() && movements > 0) {
      error = -800 - back_arm.position(degrees);
      back_arm.spin(fwd, error * kp, pct);
    }

    L2p = master.get_digital(DIGITAL_L2);

    pros::delay(25);
  }
  return 0;
}*/

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
/*	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");

	pros::lcd::register_btn1_cb(on_center_button);*/
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {

}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {

}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {

}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {

	double left_speed = 0;
	double right_speed = 0;

	double deadzone = 5;

	bool L1;
	bool L1p;

	int state = 0; // 0=down, 1=moving up, 2=up, 3=moving down

	while (true) {
		left_speed = (double)map(master.get_analog(ANALOG_LEFT_Y) / 1.27) * 120;
    right_speed = (double)map(master.get_analog(ANALOG_RIGHT_Y) / 1.27) * 120;

    if (std::abs(left_speed) < deadzone) {
      left_speed = 0;
    }
    if (std::abs(right_speed) < deadzone) {
      right_speed = 0;
    }

		if (std::abs(left_speed - right_speed) < 600) {
      left_speed = daverage(left_speed, right_speed);
      right_speed = left_speed;
    }

		if (left_speed != 0) {
			front_left.move_voltage(left_speed);
			back_left.move_volage(left_speed);
		} else {
			front_left.set_brake_mode(Pros::E_MOTOR_BRAKE_HOLD);
			back_left.set_brake_mode(Pros::E_MOTOR_BRAKE_HOLD);
			front_left.move_velocity(0);
			front_right.move_velocity(0);
		}

		if (right_speed != 0) {
			front_right.move_voltage(right_speed);
			back_right.move_voltage(right_speed);
		} else {
			front_right.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			back_right.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			front_left.move_velocity(0);
			front_right.move_velocity(0);
		}

		L1 = master.get_digital(DIGITAL_L1);

		if (four_bar_limit.get_value()) {
			state = 0;
		} else if (four_bar_limit2.get_value()) {
			state = 2;
		}


		if (L1 && !L1p) {
			if (state == 0) {
				state = 1;
			} else if (state == 2) {
				state = 3;
			}
		}

		if (state % 2 == 0) {
			four_bar.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			four_bar2.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			four_bar.move_velocity(0);
			four_bar2.move_velocity(0)
		} else if (state == 3) {
			four_bar.move_voltage(-12000);
			four_bar2.move_voltage(-12000);
		} else if (state == 1) {
			four_bar.move_voltage(12000);
			four_bar2.move_voltage(12000);
		}

		pros::screen::set_pen(COLOR_BLUE);
		pros::screen::print(pros::TEXT_MEDIUM, 3, "state: %d", state);

		L1p = L1;

		pros::delay(2);
	}
}
